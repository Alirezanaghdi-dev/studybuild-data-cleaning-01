# Data Cleaning Project - First Dataset

This repository contains the first data cleaning project for processing and standardizing customer data using Python (Pandas).

## Project Overview
The goal of this project is to clean a raw dataset, handle missing data, remove duplicates, fix formatting issues, and prepare a clean, analysis-ready dataset.

## Files Included
- data_cleaning_lianafarsi.ipynb
- cleaned_dataset_lianafarsi.xlsx
- README.md
